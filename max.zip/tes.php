
<form id="form1" name="form1" method="post" action="proses1.php">
  <input type="submit" name="button" id="button" value="Submit" />
</form>
